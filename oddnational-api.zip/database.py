import mysql.connector

# db = mysql.connector.connect(
#   host="localhost",
#   user="root",
#   password="",
#   database="emobetting_db"
# )

# db = mysql.connector.connect(
#   host="odd-national.cnrmem3900ov.ap-south-1.rds.amazonaws.com",
#   user="admin",
#   password="oddnational0721793599",
#   database="odd_national"
# )

db = mysql.connector.connect(
  host="sql866.main-hosting.eu",
  user="u124366181_emobettingvps",
  password="HZ96XCp7Lt3ZWe8%",
  database="u124366181_emobettingvps"
)
